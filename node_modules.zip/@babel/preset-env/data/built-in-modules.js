// TODO: Remove in Babel 8

module.exports = require("@babel/compat-data/native-modules");
